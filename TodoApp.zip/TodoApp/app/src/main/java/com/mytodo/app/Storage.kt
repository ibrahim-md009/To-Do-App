package com.mytodo.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** تخزين المهام محليًا على الموبايل (SharedPreferences + JSON). */
class TaskStore(context: Context) {
    private val prefs = context.getSharedPreferences("todo_tasks", Context.MODE_PRIVATE)

    fun load(): List<Task> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i -> taskFromJson(arr.getJSONObject(i)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(tasks: List<Task>) {
        val arr = JSONArray()
        for (t in tasks) arr.put(taskToJson(t))
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun loadCategories(): List<Category> {
        val raw = prefs.getString(CAT_KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Category(id = o.getLong("id"), name = o.getString("name"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveCategories(list: List<Category>) {
        val arr = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("id", c.id)
            o.put("name", c.name)
            arr.put(o)
        }
        prefs.edit().putString(CAT_KEY, arr.toString()).apply()
    }

    private fun taskToJson(t: Task): JSONObject {
        val o = JSONObject()
        o.put("id", t.id)
        o.put("title", t.title)
        o.put("type", t.repeatType.name)
        o.put("weekDays", JSONArray(t.weekDays.toList()))
        o.put("interval", t.interval)
        o.put("unit", t.unit.name)
        o.put("start", t.startDay)
        o.put("done", JSONArray(t.done.toList()))
        o.put("cat", t.categoryId)
        return o
    }

    private fun taskFromJson(o: JSONObject): Task {
        val wd = o.getJSONArray("weekDays")
        val dn = o.getJSONArray("done")
        return Task(
            id = o.getLong("id"),
            title = o.getString("title"),
            repeatType = RepeatType.valueOf(o.getString("type")),
            weekDays = (0 until wd.length()).map { wd.getInt(it) }.toSet(),
            interval = o.getInt("interval"),
            unit = IntervalUnit.valueOf(o.getString("unit")),
            startDay = o.getLong("start"),
            done = (0 until dn.length()).map { dn.getLong(it) }.toSet(),
            categoryId = o.optLong("cat", 0L)
        )
    }

    private companion object {
        const val KEY = "data"
        const val CAT_KEY = "categories"
    }
}
