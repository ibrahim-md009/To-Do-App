package com.mytodo.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import java.time.LocalDate

private fun dateText(d: LocalDate): String =
    "${dayNames.getValue(d.dayOfWeek.value)} ${d.dayOfMonth}/${d.monthValue}/${d.year}"

private const val TAB_TODAY = 0
private const val TAB_CATEGORIES = 1
private const val TAB_ALL = 2

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoApp(store: TaskStore, today: LocalDate) {
    var tasks by remember { mutableStateOf(store.load()) }
    var categories by remember { mutableStateOf(store.loadCategories()) }
    var tab by remember { mutableIntStateOf(TAB_TODAY) }
    // null = كل المهام، غير كده = تصنيف معيّن
    var filterCat by remember { mutableStateOf<Long?>(null) }

    var editorOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var deleting by remember { mutableStateOf<Task?>(null) }

    var catDialogOpen by remember { mutableStateOf(false) }
    var editingCat by remember { mutableStateOf<Category?>(null) }
    var deletingCat by remember { mutableStateOf<Category?>(null) }

    fun commit(list: List<Task>) {
        tasks = list
        store.save(list)
    }

    fun commitCats(list: List<Category>) {
        categories = list
        store.saveCategories(list)
    }

    fun toggle(t: Task) {
        val d = today.toEpochDay()
        commit(tasks.map {
            if (it.id == t.id) {
                it.copy(done = if (d in it.done) it.done - d else it.done + d)
            } else it
        })
    }

    val catName: (Task) -> String? = { t ->
        if (t.categoryId == 0L) null else categories.firstOrNull { it.id == t.categoryId }?.name
    }
    val filterName: String? = filterCat?.let { id -> categories.firstOrNull { it.id == id }?.name }
    val visibleTasks = if (filterCat == null) tasks else tasks.filter { it.categoryId == filterCat }

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("مهامي") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == TAB_TODAY,
                    onClick = { tab = TAB_TODAY },
                    icon = { Icon(Icons.Default.Check, contentDescription = null) },
                    label = { Text("اليوم") }
                )
                NavigationBarItem(
                    selected = tab == TAB_CATEGORIES,
                    onClick = { tab = TAB_CATEGORIES },
                    icon = { Icon(Icons.Default.Star, contentDescription = null) },
                    label = { Text("التصنيفات") }
                )
                NavigationBarItem(
                    selected = tab == TAB_ALL,
                    onClick = { tab = TAB_ALL },
                    icon = { Icon(Icons.Default.Menu, contentDescription = null) },
                    label = { Text("كل المهام") }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                if (tab == TAB_CATEGORIES) {
                    editingCat = null
                    catDialogOpen = true
                } else {
                    editing = null
                    editorOpen = true
                }
            }) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = if (tab == TAB_CATEGORIES) "إضافة تصنيف" else "إضافة مهمة"
                )
            }
        }
    ) { padding ->
        when (tab) {
            TAB_TODAY -> TodayTab(
                tasks = visibleTasks,
                today = today,
                categoryName = filterName,
                catLabel = catName,
                onClearFilter = { filterCat = null },
                onToggle = { toggle(it) },
                modifier = Modifier.padding(padding)
            )
            TAB_CATEGORIES -> CategoriesTab(
                categories = categories,
                tasks = tasks,
                today = today,
                onOpen = { id ->
                    filterCat = id
                    tab = TAB_TODAY
                },
                onEdit = { editingCat = it; catDialogOpen = true },
                onDelete = { deletingCat = it },
                modifier = Modifier.padding(padding)
            )
            else -> AllTab(
                tasks = tasks,
                catLabel = catName,
                onEdit = { editing = it; editorOpen = true },
                onDelete = { deleting = it },
                modifier = Modifier.padding(padding)
            )
        }
    }

    if (editorOpen) {
        TaskEditor(
            initial = editing,
            today = today,
            categories = categories,
            defaultCategoryId = filterCat ?: 0L,
            onDismiss = { editorOpen = false },
            onSave = { saved ->
                val exists = tasks.any { it.id == saved.id }
                commit(if (exists) tasks.map { if (it.id == saved.id) saved else it } else tasks + saved)
                editorOpen = false
            }
        )
    }

    if (catDialogOpen) {
        CategoryDialog(
            initial = editingCat,
            onDismiss = { catDialogOpen = false },
            onSave = { name ->
                val old = editingCat
                if (old == null) {
                    commitCats(categories + Category(System.currentTimeMillis(), name))
                } else {
                    commitCats(categories.map { if (it.id == old.id) it.copy(name = name) else it })
                }
                catDialogOpen = false
            }
        )
    }

    deleting?.let { t ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف المهمة") },
            text = { Text("هتتحذف \"${t.title}\" نهائيًا. متأكد؟") },
            confirmButton = {
                TextButton(onClick = {
                    commit(tasks.filter { it.id != t.id })
                    deleting = null
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } }
        )
    }

    deletingCat?.let { c ->
        AlertDialog(
            onDismissRequest = { deletingCat = null },
            title = { Text("حذف التصنيف") },
            text = { Text("هيتحذف التصنيف \"${c.name}\"، والمهام اللي فيه هتفضل موجودة بدون تصنيف.") },
            confirmButton = {
                TextButton(onClick = {
                    commit(tasks.map { if (it.categoryId == c.id) it.copy(categoryId = 0L) else it })
                    commitCats(categories.filter { it.id != c.id })
                    if (filterCat == c.id) filterCat = null
                    deletingCat = null
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deletingCat = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun TodayTab(
    tasks: List<Task>,
    today: LocalDate,
    categoryName: String?,
    catLabel: (Task) -> String?,
    onClearFilter: () -> Unit,
    onToggle: (Task) -> Unit,
    modifier: Modifier = Modifier
) {
    val due = tasks.filter { it.isDueOn(today) }
    val d = today.toEpochDay()
    val doneCount = due.count { d in it.done }

    Column(modifier.padding(horizontal = 16.dp)) {
        Text(dateText(today), style = MaterialTheme.typography.titleMedium)
        if (categoryName != null) {
            Spacer(Modifier.height(8.dp))
            FilterChip(
                selected = true,
                onClick = onClearFilter,
                label = { Text("التصنيف: $categoryName  ✕") }
            )
        }
        if (due.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("تم $doneCount من ${due.size}", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { doneCount.toFloat() / due.size },
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(12.dp))
        if (due.isEmpty()) {
            Text(
                if (categoryName != null) "مفيش مهام النهاردة في التصنيف ده."
                else "مفيش مهام النهاردة. اضغط + لإضافة مهمة جديدة."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                items(due, key = { it.id }) { t ->
                    val isDone = d in t.done
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggle(t) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = isDone, onCheckedChange = { onToggle(t) })
                            Column(Modifier.weight(1f)) {
                                Text(
                                    t.title,
                                    style = MaterialTheme.typography.bodyLarge,
                                    textDecoration = if (isDone) TextDecoration.LineThrough else null
                                )
                                Text(
                                    listOfNotNull(t.describe(), catLabel(t)).joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoriesTab(
    categories: List<Category>,
    tasks: List<Task>,
    today: LocalDate,
    onOpen: (Long?) -> Unit,
    onEdit: (Category) -> Unit,
    onDelete: (Category) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.padding(horizontal = 16.dp)) {
        Text("التصنيفات", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 88.dp)
        ) {
            item {
                Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(null) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text("كل المهام", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "${tasks.size} مهمة • ${tasks.count { it.isDueOn(today) }} النهاردة",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            items(categories, key = { it.id }) { c ->
                val inCat = tasks.filter { it.categoryId == c.id }
                Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(c.id) }) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "${inCat.size} مهمة • ${inCat.count { it.isDueOn(today) }} النهاردة",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = { onEdit(c) }) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل")
                        }
                        IconButton(onClick = { onDelete(c) }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف")
                        }
                    }
                }
            }
            if (categories.isEmpty()) {
                item {
                    Text("لسه ما أضفتش تصنيفات. اضغط + لإضافة تصنيف (مثلًا: شغل، بيت، صحة).")
                }
            }
        }
    }
}

@Composable
fun AllTab(
    tasks: List<Task>,
    catLabel: (Task) -> String?,
    onEdit: (Task) -> Unit,
    onDelete: (Task) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.padding(horizontal = 16.dp)) {
        if (tasks.isEmpty()) {
            Text("لسه ما أضفتش مهام. اضغط + للبدء.")
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                items(tasks, key = { it.id }) { t ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(t.title, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    listOfNotNull(t.describe(), catLabel(t)).joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            IconButton(onClick = { onEdit(t) }) {
                                Icon(Icons.Default.Edit, contentDescription = "تعديل")
                            }
                            IconButton(onClick = { onDelete(t) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryDialog(
    initial: Category?,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "تصنيف جديد" else "تعديل التصنيف") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("اسم التصنيف") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onSave(name.trim()) }) {
                Text("حفظ")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskEditor(
    initial: Task?,
    today: LocalDate,
    categories: List<Category>,
    defaultCategoryId: Long,
    onDismiss: () -> Unit,
    onSave: (Task) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var type by remember { mutableStateOf(initial?.repeatType ?: RepeatType.DAILY) }
    var days by remember { mutableStateOf(initial?.weekDays ?: emptySet()) }
    var intervalText by remember { mutableStateOf((initial?.interval ?: 2).toString()) }
    var unit by remember { mutableStateOf(initial?.unit ?: IntervalUnit.DAYS) }
    var catId by remember { mutableStateOf(initial?.categoryId ?: defaultCategoryId) }

    val interval = intervalText.toIntOrNull() ?: 0
    val valid = title.isNotBlank() && when (type) {
        RepeatType.WEEKLY -> days.isNotEmpty()
        RepeatType.CUSTOM -> interval >= 1
        else -> true
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "مهمة جديدة" else "تعديل المهمة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم المهمة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (categories.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    Text("التصنيف", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = catId == 0L,
                            onClick = { catId = 0L },
                            label = { Text("بدون") }
                        )
                        categories.forEach { c ->
                            FilterChip(
                                selected = catId == c.id,
                                onClick = { catId = c.id },
                                label = { Text(c.name) }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("التكرار", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RepeatType.values().forEach { r ->
                        FilterChip(
                            selected = type == r,
                            onClick = { type = r },
                            label = { Text(r.label) }
                        )
                    }
                }
                if (type == RepeatType.WEEKLY) {
                    Spacer(Modifier.height(12.dp))
                    Text("في أنهي أيام؟", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        weekOrder.forEach { d ->
                            FilterChip(
                                selected = d in days,
                                onClick = { days = if (d in days) days - d else days + d },
                                label = { Text(dayNames.getValue(d)) }
                            )
                        }
                    }
                }
                if (type == RepeatType.CUSTOM) {
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("كل", style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = intervalText,
                            onValueChange = { intervalText = it.filter { c -> c.isDigit() }.take(3) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.width(88.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IntervalUnit.values().forEach { u ->
                            FilterChip(
                                selected = unit == u,
                                onClick = { unit = u },
                                label = { Text(u.label) }
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "العدّ بيبدأ من يوم إنشاء المهمة.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    onSave(
                        Task(
                            id = initial?.id ?: System.currentTimeMillis(),
                            title = title.trim(),
                            repeatType = type,
                            weekDays = if (type == RepeatType.WEEKLY) days else emptySet(),
                            interval = interval.coerceAtLeast(1),
                            unit = unit,
                            startDay = initial?.startDay ?: today.toEpochDay(),
                            done = initial?.done ?: emptySet(),
                            categoryId = catId
                        )
                    )
                }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
