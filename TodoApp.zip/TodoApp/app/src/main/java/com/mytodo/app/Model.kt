package com.mytodo.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class RepeatType(val label: String) {
    ONCE("مرة واحدة"),
    DAILY("يوميًا"),
    WEEKLY("أسبوعيًا"),
    CUSTOM("كل مدة محددة")
}

enum class IntervalUnit(val label: String) {
    DAYS("أيام"),
    WEEKS("أسابيع"),
    MONTHS("شهور")
}

/** أرقام الأيام زي java.time.DayOfWeek: 1 = الاثنين ... 7 = الأحد */
val dayNames: Map<Int, String> = mapOf(
    1 to "الاثنين",
    2 to "الثلاثاء",
    3 to "الأربعاء",
    4 to "الخميس",
    5 to "الجمعة",
    6 to "السبت",
    7 to "الأحد"
)

/** ترتيب عرض الأيام (الأسبوع بيبدأ السبت) */
val weekOrder: List<Int> = listOf(6, 7, 1, 2, 3, 4, 5)

data class Task(
    val id: Long,
    val title: String,
    val repeatType: RepeatType = RepeatType.DAILY,
    val weekDays: Set<Int> = emptySet(),
    val interval: Int = 1,
    val unit: IntervalUnit = IntervalUnit.DAYS,
    /** تاريخ بداية المهمة (epochDay) - العدّ بيبدأ منه في التكرار المخصص */
    val startDay: Long,
    /** الأيام اللي اتعملت فيها المهمة (epochDay) */
    val done: Set<Long> = emptySet()
)

/** هل المهمة مطلوبة في اليوم ده؟ */
fun Task.isDueOn(date: LocalDate): Boolean {
    val start = LocalDate.ofEpochDay(startDay)
    if (date.isBefore(start)) return false
    return when (repeatType) {
        // المهمة لمرة واحدة بتفضل ظاهرة لحد ما تتعمل
        RepeatType.ONCE -> done.isEmpty() || done.contains(date.toEpochDay())
        RepeatType.DAILY -> true
        RepeatType.WEEKLY -> weekDays.contains(date.dayOfWeek.value)
        RepeatType.CUSTOM -> {
            val n = interval.coerceAtLeast(1)
            when (unit) {
                IntervalUnit.DAYS ->
                    ChronoUnit.DAYS.between(start, date) % n == 0L
                IntervalUnit.WEEKS ->
                    ChronoUnit.DAYS.between(start, date) % (7L * n) == 0L
                IntervalUnit.MONTHS -> {
                    val m = ChronoUnit.MONTHS.between(start, date)
                    m % n == 0L && start.plusMonths(m) == date
                }
            }
        }
    }
}

private fun intervalPhrase(unit: IntervalUnit, n: Int): String {
    val forms = when (unit) {
        IntervalUnit.DAYS -> listOf("يوم", "يومين", "أيام", "يومًا")
        IntervalUnit.WEEKS -> listOf("أسبوع", "أسبوعين", "أسابيع", "أسبوعًا")
        IntervalUnit.MONTHS -> listOf("شهر", "شهرين", "أشهر", "شهرًا")
    }
    return when {
        n <= 1 -> "كل ${forms[0]}"
        n == 2 -> "كل ${forms[1]}"
        n in 3..10 -> "كل $n ${forms[2]}"
        else -> "كل $n ${forms[3]}"
    }
}

/** وصف التكرار بالعربي */
fun Task.describe(): String = when (repeatType) {
    RepeatType.ONCE -> "مرة واحدة"
    RepeatType.DAILY -> "كل يوم"
    RepeatType.WEEKLY ->
        "كل " + weekOrder.filter { it in weekDays }.joinToString("، ") { dayNames.getValue(it) }
    RepeatType.CUSTOM -> intervalPhrase(unit, interval)
}
